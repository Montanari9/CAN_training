
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  ** This notice applies to any and all portions of this file
  * that are not between comment pairs USER CODE BEGIN and
  * USER CODE END. Other portions of this file, whether 
  * inserted by the user or by software development tools
  * are owned by their respective copyright owners.
  *
  * COPYRIGHT(c) 2018 STMicroelectronics
  *
  * Redistribution and use in source and binary forms, with or without modification,
  * are permitted provided that the following conditions are met:
  *   1. Redistributions of source code must retain the above copyright notice,
  *      this list of conditions and the following disclaimer.
  *   2. Redistributions in binary form must reproduce the above copyright notice,
  *      this list of conditions and the following disclaimer in the documentation
  *      and/or other materials provided with the distribution.
  *   3. Neither the name of STMicroelectronics nor the names of its contributors
  *      may be used to endorse or promote products derived from this software
  *      without specific prior written permission.
  *
  * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
  * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
  * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
  * DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
  * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
  * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
  * SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
  * CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
  * OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
  * OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
  *
  ******************************************************************************
  */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "stm32f0xx_hal.h"
#include "can.h"
#include "usart.h"
#include "gpio.h"

/* USER CODE BEGIN Includes */
#include "stdio.h"
#define TEST_CAN_RANGE 1
#define INIT_RANGE 0x100
#define MASK 0x700

#define CAN_NODE1 1
//#define CAN_NODE2 2
//#define CAN_NODE3 3

/*The filter makes use of two 29-bit numbers - composed in a FilterId and a FilterMask and
 *there are two modes to be used:
 *- Identifier Mode
 *- Mask Mode.
 *The identifier mode is pretty simple: both numbers represent IDs that should be caught by the filter.
 *For the Mask Mode, the FilterMask specifies which bits to compare with the FilterId, examples:
 *For MASK = 0x1FFFFFFE and ID = 0x00000002 will catch IDs 2 and 3.
 *For MASK = 0x1FFFFFF8 and ID = 0x00000000 will catch IDs 0 to 7.
 *For MASK = 0x1FFFFFFF and ID = 0x00000008 will catch ID 8.
 *For MASK = 0x00000001 and ID = 0x00000001 will catch all odd IDs.
 *For MASK = 0x00000000, all IDs get passed ad the filter is disable
*/
//#define NO_CAN_FILTER 1
//#define IDENTIFIER_CAN_FILTER 2
#define MASK_CAN_FILTER 3

/*Every CAN message has an associated ID sent with its content.
 *A receiver can decide on a hardware level which IDs to accept by using 27 so called filter banks
 *which can implement either one 32-bit filter or two 16-bit filter.
 *The usage of these also depends on your scale of CAN Msg IDs which can either be standard IDs (11-bit)
 *or extended IDs (29-bit). In this example this can be configure by the defines below
*/
#ifdef NO_CAN_FILTER
#define ID_STANDARD 1
#endif
#ifdef NO_CAN_FILTER
#define ID_STANDARD 1
#endif
#ifdef MASK_CAN_FILTER
#define ID_STANDARD 1
//#define ID_EXTENDED 2
#endif
/* USER CODE END Includes */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/* Private variables ---------------------------------------------------------*/
uint8_t ubKeyNumber = 0x0;
uint8_t ubLedBlinkTime = 0x0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */
/* Private function prototypes -----------------------------------------------*/
void CAN_Config(void);
void LED_Display(uint8_t LedStatus);
int validationfilter(void);
/* USER CODE END PFP */

/* USER CODE BEGIN 0 */
CanTxMsgTypeDef        TxMessage;
CanRxMsgTypeDef        RxMessage;
CanRxMsgTypeDef        RxMessage1;
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  *
  * @retval None
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	CAN_FilterConfTypeDef  sFilterConfig;
  /* USER CODE END 1 */

  /* MCU Configuration----------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /*##-1- Configure the CAN peripheral #######################################*/
  hcan.pTxMsg = &TxMessage; //Tx
  hcan.pRxMsg = &RxMessage; //Rx FIFO0
  hcan.pRx1Msg = &RxMessage1; //Rx FIFO1
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_CAN_Init();
  /* USER CODE BEGIN 2 */

  printf("\nHardware Init Done\r\n");
  printf("\nFilter Configuration Start\r\n");
#ifdef TEST_CAN_RANGE
  validationfilter();
#endif
  /*##-2- Configure the CAN Filter ###########################################*/
#ifdef NO_CAN_FILTER
  sFilterConfig.FilterNumber = 0;
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  sFilterConfig.FilterIdHigh = 0x0000;
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000;
  sFilterConfig.FilterMaskIdLow = 0x0000;
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 14;
  HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
#elif IDENTIFIER_CAN_FILTER
  sFilterConfig.FilterNumber = 0;//CAN1 =0..13] CAN2[14..27]
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDLIST;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
#ifdef  CAN_NODE1
  //will enable IDLIST in FIFO0 for 0x321 and 0x123 in FIFO1
  sFilterConfig.FilterIdHigh = (0x321<<5); //filter for 0x321
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000; //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterMaskIdLow = 0x0000;  //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 0;
  HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
  sFilterConfig.FilterNumber = 1;//CAN1 =0..13] CAN2[14..27]
  sFilterConfig.FilterIdHigh = (0x123<<5); //filter for 0x123
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000; //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterMaskIdLow = 0x0000;  //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO1;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 0;
  HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
#else
  sFilterConfig.FilterIdHigh = (0x100<<5); //filter for 0x100
  sFilterConfig.FilterIdLow = 0x0000;
  sFilterConfig.FilterMaskIdHigh = 0x0000; //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterMaskIdLow = 0x0000;  //in IDLIST, there is no MASK to fill
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 0;
  HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
#endif
#elif MASK_CAN_FILTER
  /*
   * The reasoning behind this bit shifting is best understood by having a look at the referenced manual
   * on p. 821. Whereas High and Low are the higher and lower indices of the filter registers respectively.
  */
  sFilterConfig.FilterNumber = 0; //CAN1 =0..13] CAN2[14..27] ->there is no can2 in STM32F042 or STM32F091 with 64pin or less
  sFilterConfig.FilterMode = CAN_FILTERMODE_IDMASK;
  sFilterConfig.FilterScale = CAN_FILTERSCALE_32BIT;
  /* Filter 0x100..0x1FF */
  sFilterConfig.FilterIdHigh = INIT_RANGE<<5; //11-BIT id IN TOP BITS
  sFilterConfig.FilterIdLow = 0;
  sFilterConfig.FilterMaskIdHigh = MASK<<5;
  sFilterConfig.FilterMaskIdLow = 0;
  sFilterConfig.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  sFilterConfig.FilterActivation = ENABLE;
  sFilterConfig.BankNumber = 0;//hcan.pRxMsg->Data[1];;
  HAL_CAN_ConfigFilter(&hcan, &sFilterConfig);
#endif
  /*##-3- Configure Transmission process #####################################*/
#ifdef NO_CAN_FILTER
  hcan.pTxMsg->StdId = 0x321;
  hcan.pTxMsg->ExtId = 0x00;
  hcan.pTxMsg->RTR = CAN_RTR_DATA;
#ifdef ID_EXTENDED
  hcan.pTxMsg->IDE = CAN_ID_EXT; //set extended (29-bit)
#elif ID_STANDARD
  hcan.pTxMsg->IDE = CAN_ID_STD; //set standard (11-bit)
#endif
#elif IDENTIFIER_CAN_FILTER
#ifdef CAN_NODE1
  hcan.pTxMsg->StdId = 0x100;
  hcan.pTxMsg->ExtId = 0x00;
#elif CAN_NODE2
  hcan.pTxMsg->StdId = 0x123;
  hcan.pTxMsg->ExtId = 0x00;
#elif CAN_NODE3
  hcan.pTxMsg->StdId = 0x321;
  hcan.pTxMsg->ExtId = 0x00;
#endif
  hcan.pTxMsg->RTR = CAN_RTR_DATA;
#ifdef ID_EXTENDED
  hcan.pTxMsg->IDE = CAN_ID_EXT; //set extended (29-bit)
#elif ID_STANDARD
  hcan.pTxMsg->IDE = CAN_ID_STD; //set standard (11-bit)
#endif
#endif
#ifdef MASK_CAN_FILTER
#ifdef CAN_NODE1
  hcan.pTxMsg->StdId = 0x100;
  hcan.pTxMsg->ExtId = 0x00;
#elif CAN_NODE2
  hcan.pTxMsg->StdId = 0x123;
  hcan.pTxMsg->ExtId = 0x00;
#elif CAN_NODE3
  hcan.pTxMsg->StdId = 0x321;
  hcan.pTxMsg->ExtId = 0x00;
#endif
  hcan.pTxMsg->RTR = CAN_RTR_DATA;
#ifdef ID_EXTENDED
  hcan.pTxMsg->IDE = CAN_ID_EXT; //set extended (29-bit)
#elif ID_STANDARD
  hcan.pTxMsg->IDE = CAN_ID_STD; //set standard (11-bit)
#endif
#endif
  hcan.pTxMsg->DLC = 2;
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  HAL_CAN_Receive_IT(&hcan, CAN_FIFO0);
#ifdef IDENTIFIER_CAN_FILTER
#ifdef CAN_NODE1
  HAL_CAN_Receive_IT(&hcan, CAN_FIFO1);
#endif
#endif
  while (1)
  {

  /* USER CODE END WHILE */

  /* USER CODE BEGIN 3 */
	  while (HAL_GPIO_ReadPin(B1_GPIO_Port,B1_Pin) == GPIO_PIN_RESET) //key pressed
	  {
		  if (ubKeyNumber == 0x4)
		  {
			  ubKeyNumber = 0x00;
		  }
		  else
		  {
			  LED_Display(++ubKeyNumber);

			  /* Set the data to be transmitted */
			  hcan.pTxMsg->Data[0] = ubKeyNumber;
			  hcan.pTxMsg->Data[1] = 0xAD;

			  /*##-3- Start the Transmission process ###############################*/
			  HAL_CAN_Transmit(&hcan, 10);
			  HAL_Delay(10);

			  while (HAL_GPIO_ReadPin(B1_GPIO_Port,B1_Pin) != GPIO_PIN_SET)
			  {
			  }
		  }
	  }
  }
  /* USER CODE END 3 */

}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{

  RCC_OscInitTypeDef RCC_OscInitStruct;
  RCC_ClkInitTypeDef RCC_ClkInitStruct;
  RCC_PeriphCLKInitTypeDef PeriphClkInit;

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = 16;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL12;
  RCC_OscInitStruct.PLL.PREDIV = RCC_PREDIV_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Initializes the CPU, AHB and APB busses clocks 
    */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_1) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    _Error_Handler(__FILE__, __LINE__);
  }

    /**Configure the Systick interrupt time 
    */
  HAL_SYSTICK_Config(HAL_RCC_GetHCLKFreq()/1000);

    /**Configure the Systick 
    */
  HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);

  /* SysTick_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(SysTick_IRQn, 0, 0);
}

/* USER CODE BEGIN 4 */
void HAL_SYSTICK_Callback(void){
	static uint16_t u16LedBlinkCounter = 0;
	if(u16LedBlinkCounter){
			u16LedBlinkCounter--;
	}
	else{
		u16LedBlinkCounter = 100*ubLedBlinkTime;//delay based in the received value
		HAL_GPIO_TogglePin(LD2_GPIO_Port,LD2_Pin);
	}

}
/**
  * @brief  Transmission  complete callback in non blocking mode
  * @param  hcan: pointer to a CAN_HandleTypeDef structure that contains
  *         the configuration information for the specified CAN.
  * @retval None
  */
void HAL_CAN_RxCpltCallback(CAN_HandleTypeDef *hcan)
{

#ifdef IDENTIFIER_CAN_FILTER
#ifdef CAN_NODE1
	//Only check the State for busy if both FIFOs are used, otherwise it will return as HAL_CAN_STATE_READY
	//check FIFO1
	if(hcan->State == HAL_CAN_STATE_BUSY_RX0)//check if there is pending message in CAN_FIFO_1 (the API set the FIFO0 as busy)
	{
		if((hcan->pRx1Msg->StdId == 0x123)&& (hcan->pRx1Msg->IDE == CAN_ID_STD) && (hcan->pRx1Msg->DLC == 2)){
			LED_Display(hcan->pRx1Msg->Data[0]);
			ubKeyNumber = hcan->pRx1Msg->Data[0];
		}
	}
	//check FIFO0
	if(hcan->State == HAL_CAN_STATE_BUSY_RX1)//check if there is pending message in CAN_FIFO_1 (the API set the FIFO1 as busy)
#endif
#endif
	{	//In NO_CAN_FILTER example, check if any NODE has sent the message in FIFO0
		if ((hcan->pRxMsg->StdId == 0x321) && (hcan->pRxMsg->IDE == CAN_ID_STD) && (hcan->pRxMsg->DLC == 2))
		{
			LED_Display(hcan->pRxMsg->Data[0]);
			ubKeyNumber = hcan->pRxMsg->Data[0];
		}
		//In IDENTIFIER_CAN_FILTER and in MASK_CAN_FILTER examples, check if NODE1 sent the message in FIFO0
		if ((hcan->pRxMsg->StdId == 0x100) && (hcan->pRxMsg->IDE == CAN_ID_STD) && (hcan->pRxMsg->DLC == 2))
		{
			LED_Display(hcan->pRxMsg->Data[0]);
			ubKeyNumber = hcan->pRxMsg->Data[0];
		}
		//In MASK_CAN_FILTER example, check if NODE2 sent the message in FIFO0
		if ((hcan->pRxMsg->StdId == 0x123) && (hcan->pRxMsg->IDE == CAN_ID_STD) && (hcan->pRxMsg->DLC == 2))
		{
			LED_Display(hcan->pRxMsg->Data[0]);
			ubKeyNumber = hcan->pRxMsg->Data[0];
		}
	}
	/* Receive */
	HAL_CAN_Receive_IT(hcan, CAN_FIFO0);
#ifdef IDENTIFIER_CAN_FILTER
#ifdef CAN_NODE1
	HAL_CAN_Receive_IT(hcan, CAN_FIFO1);
#endif
#endif
}

/**
  * @brief  Turns ON/OFF the dedicated LED.
  * @param  LedStatus: LED number from 0 to 3
  * @retval None
  */
void LED_Display(uint8_t LedStatus)
{
  /* Turn OFF the LED */
  HAL_GPIO_WritePin(LD2_GPIO_Port,LD2_Pin,GPIO_PIN_RESET);

  switch(LedStatus)
  {
    case (1):
      /* Blink LED every 100ms */
    	ubLedBlinkTime = 1;
      break;

    case (2):
		/* Blink LED every 200ms */
    	ubLedBlinkTime = 2;
      break;

    case (3):
		/* Blink LED every 300ms */
    	ubLedBlinkTime = 3;
      break;

    case (4):
		/* Blink LED every 400ms */
    	ubLedBlinkTime = 4;
      break;
    default:
      break;
  }
}
#define USE_UART_PRINT 1

void __io_putchar(char ch) {
#ifdef USE_UART_PRINT
	// Code to write character 'ch' on the UART
	HAL_UART_Transmit(&huart2, (uint8_t *)&ch, 1, 10);
#else
	ITM_SendChar(ch);
#endif
}

int _write(int file, char *ptr, int len)
{
	int DataIdx;
	for (DataIdx = 0; DataIdx < len; DataIdx++)
	{
		__io_putchar(*ptr++);
	}
	return len;
}
#ifdef USE_UART_PRINT
int __io_getchar(void) {
	uint8_t ch;
	if (__HAL_UART_GET_FLAG(&huart2, UART_FLAG_ORE))
		__HAL_UART_CLEAR_FLAG(&huart2, UART_FLAG_ORE);
	while (!__HAL_UART_GET_FLAG(&huart2, UART_FLAG_RXNE));
	ch = (uint8_t) (huart2.Instance->RDR & (uint8_t) 0x00FF);
	return (int) ch;
}
int _read (int file, char *ptr, int len)
{
	len = 1;
	*ptr = __io_getchar();
	return len;
}
#endif

// CAN Filtering Simulation:
int validationfilter(void)
{
     int id;

     for(id=0; id<0x800; id++)
          if ((id & MASK) == INIT_RANGE) printf("%03X\n", id);
     return(1);
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @param  file: The file name as string.
  * @param  line: The line in file as a number.
  * @retval None
  */
void _Error_Handler(char *file, int line)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  while(1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t* file, uint32_t line)
{ 
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     tex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/**
  * @}
  */

/**
  * @}
  */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
